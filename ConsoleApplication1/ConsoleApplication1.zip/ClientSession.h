#ifndef CLIENT_SESSION_H
#define CLIENT_SESSION_H

//定义包长
#define MAX_NET_LEN 4096

#include <iostream>
#include <fstream>
#include <string.h>
#include <boost/smart_ptr.hpp>
#include <boost/asio.hpp>
#include <boost/asio/io_service.hpp>
#include <boost/bind.hpp>

using std::string;
using std::fstream;

namespace boostNet = boost::asio::ip;


struct nshead_t
{
	unsigned short body_len;    //网络包长
	unsigned short body_id;     //网络包ID
	char* body_content;			//包体
};


class ClientSession:public boost::enable_shared_from_this<ClientSession>
{
public:
	ClientSession(void);
	virtual ~ClientSession(void);
	string& getIp();			//包ID				
	void start();				//开始				
	void disconnect();			//断开				
	bool isOpen();				//验证是否是连接状态				
	void sendMsg();				//发送消体				
	void receiverMsg();			//接收消息				
	void receiverHandler(const boost::system::error_code& error,char* headBuff);							//读取包头成功
	boostNet::tcp::socket& getSocket();			

private:
	boostNet::tcp::socket mSocket;
	int OFF_SET;                                

};

#endif
