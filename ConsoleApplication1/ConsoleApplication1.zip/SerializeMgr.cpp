#include "SerializeMgr.h"


SerializeMgr::SerializeMgr(void)
{
}


SerializeMgr::~SerializeMgr(void)
{
}
