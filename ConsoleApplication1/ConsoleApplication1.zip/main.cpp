#include <iostream>
#include <boost/smart_ptr.hpp>
#include <boost/asio.hpp>
#include <boost/asio/buffered_stream.hpp>

#include <google/protobuf/io/zero_copy_stream.h>
#include <google/protobuf/io/zero_copy_stream_impl_lite.h>
#include <google/protobuf/io/coded_stream.h>


#include "protocbuff/chatMsg.pb.h"
#include "ChatServer.h"

#include "ClassFactory.h"

using std::cout;
using std::endl;

using namespace boost;
using namespace google::protobuf::io;
using namespace classFactory;


//�˿ں�
short domainPort = 8100;

//����������
boost::asio::io_service globalIoSvr;

//����˵�
boost::asio::ip::tcp::endpoint endPoint(boost::asio::ip::tcp::v4(),domainPort);

//�������Ӿ��
boost::asio::ip::tcp::acceptor svrAccept(globalIoSvr,endPoint);

//�������
ChatServer chatServer;

int main(int argc,char* argv[])
{
	cout << "chat server start." << endl;

	chatServer.beginAccept();

	//���յ����ݰ������߳�
	//thread serializeThread(boost::bind(&ChatServer::threadSerializedBody,&chatServer));

	globalIoSvr.run();
    return 0;
}