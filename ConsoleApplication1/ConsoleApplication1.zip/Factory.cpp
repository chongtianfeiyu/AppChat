#include "Factory.h"


Factory::Factory(void)
{
}


Factory::~Factory(void)
{
}
