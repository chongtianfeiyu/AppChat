#include "ChatServer.h"
#include "NetResponse.h"


using namespace response;

extern short domainPort;
extern boost::asio::io_service globalIoSvr;
extern boost::asio::ip::tcp::endpoint endPoint;
extern boost::asio::ip::tcp::acceptor svrAccept;

ChatServer::ChatServer(void)
{
	response::callBackMap.insert(make_pair(protocol::XYID_LOGIN,response::loginServer_response));
}

ChatServer::~ChatServer(void)
{
	sessionList.clear();
}

void ChatServer::start()
{
	beginAccept();
}

void ChatServer::stop()
{
	vector<session_ptr>::iterator iter = sessionList.begin();
	vector<session_ptr>::iterator eiter = sessionList.end();
	while(iter != eiter)
	{
		iter++;
		((session_ptr)*iter)->disconnect();
	}
	sessionList.clear();
}

void ChatServer::beginAccept()
{
	session_ptr session(new ClientSession());
	svrAccept.async_accept(session->getSocket(),boost::bind(&ChatServer::acceptHandler,this,boost::asio::placeholders::error,session));
}

void ChatServer::acceptHandler(const boost::system::error_code& error,session_ptr& session)
{
	cout << "accept a new client." << endl;
	session->start();
	sessionList.push_back(session);
	beginAccept();
}

void ChatServer::appendToSerializeList(nshead_t& netBody)
{
	map<int,response::callBack>::iterator find;
	find = response::callBackMap.find(netBody.body_id);
	if(find != response::callBackMap.end())
	{
		cout << "response handler " << netBody.body_id << endl;
		find->second(netBody.body_content,netBody.body_len);
	}
	else
	{
		cout << "response fault" << netBody.body_id << endl;
	}	
}


