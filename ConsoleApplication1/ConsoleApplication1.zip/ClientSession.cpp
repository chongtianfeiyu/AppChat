#include <iostream>

#include "ClientSession.h"
#include "ChatServer.h"

#include "protocbuff/chatMsg.pb.h"
#include "NetResponse.h"

#include <google/protobuf/io/zero_copy_stream.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <google/protobuf/io/coded_stream.h>

using namespace std;
using namespace google::protobuf::io;

extern short domainPort;
extern boost::asio::io_service globalIoSvr;
extern boost::asio::ip::tcp::endpoint endPoint;
extern boost::asio::ip::tcp::acceptor svrAccept;

//�������
extern ChatServer chatServer;


ClientSession::ClientSession(void):mSocket(globalIoSvr),OFF_SET(2)
{
	
}


ClientSession::~ClientSession(void)
{

}


string& ClientSession::getIp()
{
	return mSocket.remote_endpoint().address().to_string();
}


void ClientSession::start()
{
	receiverMsg();
}

//�Ͽ�����
void ClientSession::disconnect()
{
	mSocket.close();
}

bool ClientSession::isOpen()
{
	return mSocket.is_open();
}

void ClientSession::sendMsg()
{
}

void ClientSession::receiverMsg()
{
	char pHeadBuf[MAX_NET_LEN];
	memset(&pHeadBuf,0,MAX_NET_LEN);
	mSocket.async_read_some(boost::asio::buffer(&pHeadBuf,MAX_NET_LEN),boost::bind(&ClientSession::receiverHandler,shared_from_this(),boost::asio::placeholders::error,(char*)&pHeadBuf));
}

void ClientSession::receiverHandler(const boost::system::error_code& error,char* headBuff)
{

	//����
	short body_len = *(unsigned short*)headBuff;
	headBuff += sizeof(short);

	//��ID
	short body_id = *(unsigned short*)headBuff;
	headBuff += sizeof(short);

	//��ͷ
	nshead_t nsHead = {body_len - OFF_SET,body_id,headBuff};

	protocol::loginServer* logSvr = new protocol::loginServer();
	logSvr->ParseFromArray(nsHead.body_content,nsHead.body_len);
	cout << "userID:" << logSvr->userid() << endl;

	//chatServer.appendToSerializeList(nsHead);

	//������������
	receiverMsg();
}


boostNet::tcp::socket& ClientSession::getSocket()
{
	return mSocket;
}
