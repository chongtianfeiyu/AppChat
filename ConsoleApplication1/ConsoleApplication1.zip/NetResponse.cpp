#include "NetResponse.h"
#include "protocbuff/chatMsg.pb.h"
#include <iostream>;

using namespace std;
using namespace response;

//��¼�����ص���������
void response::loginServer_response(char* msgContent,unsigned short& msgLen)
{
	protocol::loginServer* loginMsg = new protocol::loginServer();
	loginMsg->ParseFromArray(msgContent,msgLen);
	cout << loginMsg->userid() << endl;
}