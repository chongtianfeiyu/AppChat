#ifndef SERIALIZE_MGR_H
#define SERIALIZE_MGR_H

#include <map>



namespace serialize
{

	//typedef std::map<int,CreateFUNC> classMap;

	class SerializeMgr
	{
	public:
		SerializeMgr(void);
		~SerializeMgr(void);
	};
};
#endif
